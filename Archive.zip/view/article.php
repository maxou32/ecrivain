<h1>C'est un article dans la view</h1>


<?php echo $message.' '.$annee;?>


<?php foreach($movies as $movie):?>

    <?php echo $movie->getTitle();?><br/>

<?php endforeach;?>
