<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <title>Sens Critique Like</title>
    <link rel="stylesheet" href="<?php echo ASSETS;?>normalize.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS;?>style.css"/>
</head>
<body>
<header>

    <div id="logo">
        <img src="<?php echo ASSETS;?>img/logo.png"/>
    </div>
    <div id="top-menu">
        <div id="search">
            <input type="text" name="search" placeholder="Recherche"/>
        </div>
        <nav>
            <ul id="menu">
                <li>
                    <a href="movie.html">Films</a>
                </li>
                <li>
                    <a href="book.html">Livres</a>
                </li>
            </ul>


        </nav>
    </div>
    <br style="clear: both"/>
</header>

    <div id="slider">
        <img src="<?php echo ASSETS;?>img/pulp.png"/>
    </div>
<div id="main-content">


    <?php echo $content;?>


</div>
<br style="clear: both"/>

<div id="footer2" style="background-color: red">
    <a href="ajout.php">Ajout</a>

    ---

    <a href="login.php">Login</a>

</div>


</body>
</html>