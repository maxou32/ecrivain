<?php


class Routeur
{

    protected $request;

    protected $paths = array (
                                'mes-supers-articles.html' => array( 'controlleur' => 'Admin',  'action' => 'List'),
                                'mes-livres'   => array( 'controlleur' => 'Article',  'action' => 'Book')

                                );

    public function __construct($request)
    {
        $this->request = $request;
        
    }

    public function getPathName()
    {
        $element = explode('/', $this->request);
        return $element['0'];
    }

    public function getParams()
    {
        $elements = explode('/', $this->request);
        unset($elements[0]);

        for($i = 1; $i < count($elements); $i++)
        {
            $params[$elements[$i]] = $elements[$i+1];
            $i++;
        }

        return $params;

    }
    

    public function renderControlleur()
    {

        $pathname = $this->getPathName();
        
        $params = $this->getParams();

        if(array_key_exists($pathname, $this->paths))
        {

            $controllleur = $this->paths[$pathname]['controlleur'];
            $action = "execute".$this->paths[$pathname]['action'];

            $controllleur = new $controllleur();
            $controllleur->$action($params);

            //include_once(CONTROLLEUR.$this->paths[$this->request]);

        }

        // if assets


        // erreur 404


    }



}