<?php


class Movie
{

    protected $title;
    protected $img;
    protected $note;
    protected $created_at


    public function setTitle($string)
    {
        $this->title = $string;
    }

  	public function getTitle()
    {
        return ucfirst($this->title);
    }


    public function setNote($string)
    {
        $this->note = $string;
    }
    
       public function getNote()
    {
        return $this->note;
    }


    public function setImg($string)
    {
        $this->img = $string;
    }

    public function getImg()
    {
        return $this->img;
    }
    
     public function setCreatedAt($created)
    {
    	$this->created_at = $created;
    }
    
    public function getCreatedAt()
    {
    	return $this->created_at
    }
    

    public function getPersonalCode()
    {
        return sha($this->title);
    }


}