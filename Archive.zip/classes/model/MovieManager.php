<?php

class MovieManager
{
    private $bdd;
    
    public function __construct()
    {
            $bdd = new PDO("mysql:host=localhost;dbname=senscritique;charset=utf8", "root", "root");
            $this->bdd = $bdd;
    }

    public function getMovies()
    {
            $bdd = $this->bdd;
            $req = $bdd->prepare("SELECT * FROM movie");
            $req->execute();
            while ($row = $req->fetch(PDO::FETCH_ASSOC)) {

                $movie = new Movie();
                $movie->setTitle($row['title']);
                $movie->setImg($row['img']);
                $movie->setNote($row['note']);

                $movies[] = $movie;
            };
        return $movies;
    }


}