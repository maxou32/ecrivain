<?php

class Article
{

    public function executeList($params = null)
    {
        $em = new MovieManager();
        $movies = $em->getMovies();

        $view = new View('article');
        $view->render(array('movies' => $movies));
    }


    public function executeBook()
    {
        $view = new View('book');
        $view->render(array('annee' => 2017, 'message' => 'hello world'));
    }

}
