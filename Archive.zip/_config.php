<?php
// show errors if not in php.ini
ini_set('display_errors','on');
error_reporting(E_ALL);

class MyAutoload
{


    public static function start()
    {
        spl_autoload_register(array(__CLASS__, 'autoload'));

        $host = 'http://'.$_SERVER['HTTP_HOST'].'/';
        $root =  $_SERVER['DOCUMENT_ROOT'].'/';

        // constant
        define("HOST", $host.'212/' );
        define("ROOT", $root.'212/' );

        define("CONTROLLEUR", ROOT."controlleur/");
        define("VIEW", ROOT."view/");
        define("CLASSE", ROOT."classes/");
        define("MODEL", CLASSE."model/");

        define("ASSETS", HOST."assets/");

    }

    public static function autoload($class)
    {
        if(file_exists(MODEL.$class.'.php')) {
            include_once(MODEL.$class.'.php');
        } else if(file_exists(CONTROLLEUR.$class.'.php')) {
            include_once(CONTROLLEUR.$class.'.php');
        } else {
            include_once(CLASSE.$class.'.php');
        }
    }

}