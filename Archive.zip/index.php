<?php
include_once ('_config.php');

MyAutoload::start();

$request = $_GET['request'];

$router = new Routeur($request);
$router->renderControlleur();